#ifndef TEXT_H
#define TEXT_H

#include "shape.h"

class Text : public Shape
{
public:
    Text(string shapeType,
         QPoint coords,
         QString textString,
         GlobalColor   textColor,
         AlignmentFlag textAlignment,
         QFont font,
         int length,
         int width);


    void Draw(QWidget* renderArea) override;

    double Perimeter() const override;
    double Area()      const override;

    bool isPointInside(const QPoint& point) const override;

    void setText(QString text);
    void setLength(int newLength);
    void setWidth(int newWidth);
    void setX(int newX);
    void setY(int newY);
    void setAlignment(Qt::AlignmentFlag alignment);

    QFont& setInternalFont();
    
    /************* ACCESSOR FUNCTIONS *************/
    int           getLength()        const;
    int           getWidth()         const;
    QString       getTextString()    const;
    GlobalColor   getTextColor()     const;
    QFont         getFont()          const;
    AlignmentFlag getTextAlignment() const;
    int           getFontStyle()     const;
    QFont::Weight getFontWeight()    const;
    /**********************************************/

private:
    int length;
    int width;

    QString       textString;
    GlobalColor   textColor;
    QFont         font;
    AlignmentFlag textAlignment;
};

#endif // TEXT_H
