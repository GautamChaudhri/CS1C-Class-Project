This is the list of what each file is for
Possibly change these files to json

shapes.txt      *Holds all possible shapes that can be used in a project 

render_area.json     *Holds all persistent shape data. Is only fetched or modified on app startup,
                        app shutdown, adding, updating, or deleting shapes. 
